Hello there!
This is the project file for project 5.
The report and all work regarding the test cases can be found in the documents folder. The source code, executable and instructions can be found in the code folder.
Please read the report (project5report.pdf) first, before moving on to the code. 
You can find details on input and output specifications in the report, as well as in documents/io_specifcations.md