Hello there!
This is group 6's project file for project 5.
The report and all work regarding the test cases can be found in the documents folder. The source code, executable and instructions can be found in the code folder.
Please read the report (cy_2020G06_P5.pdf) first, before moving on to the code. 
You can find details on input and output specifications in the report, as well as in documents/io_specifcations.md

Thanks! :D

Group 6:
Anna Tang (Leader)
Fu Bo 
Joshua Malmberg